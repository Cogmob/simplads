from named_tup import NamedTup

SimpladResult = NamedTup('SimpladResult', 'val delta_map')
