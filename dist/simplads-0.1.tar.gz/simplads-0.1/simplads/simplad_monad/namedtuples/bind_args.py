from named_tup import NamedTup

BindArgs = NamedTup('BindArgs', 'bound deltas')
