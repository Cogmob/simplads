from enum import Enum

class DeltaType(Enum):
    default = 1
    configured = 2
    finish = 3
    list = 4
