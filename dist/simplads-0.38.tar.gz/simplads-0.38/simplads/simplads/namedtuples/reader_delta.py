from .named_tup import NamedTup

ReaderDelta = NamedTup('ReaderDelta', 'keys overwrite has_new_read_func new_read_func')
