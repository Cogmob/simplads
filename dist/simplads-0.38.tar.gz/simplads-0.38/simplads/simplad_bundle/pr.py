import pprint

def pr(i):
    print(pprint.pprint(i, indent=4))
    return i
