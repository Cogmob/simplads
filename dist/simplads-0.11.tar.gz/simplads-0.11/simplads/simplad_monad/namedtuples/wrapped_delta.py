from .named_tup import NamedTup

WrappedDelta = NamedTup('WrappedDelta', 'type delta')
