from named_tup import NamedTup

DeltaOverwrite = NamedTup('DeltaOverwrite', 'overwrite new_value')
