from .named_tup import NamedTup

ReaderResult = NamedTup('ReaderResult', 'read_val val')
