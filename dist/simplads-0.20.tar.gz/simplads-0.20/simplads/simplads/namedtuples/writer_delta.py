from .named_tup import NamedTup

WriterDelta = NamedTup('WriterDelta', 'has_data keys data has_new_write_func new_write_func')
