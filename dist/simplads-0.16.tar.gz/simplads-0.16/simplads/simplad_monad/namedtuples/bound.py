from .named_tup import NamedTup

Bound = NamedTup('Bound', 'unbound annotation')
