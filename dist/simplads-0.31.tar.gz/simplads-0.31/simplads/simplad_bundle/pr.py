def pr(i):
    print i
    return i
