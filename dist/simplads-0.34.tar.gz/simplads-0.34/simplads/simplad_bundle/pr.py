import pprint
pp = pprint.PrettyPrinter(indent=4)

def pr(i):
    pp.pprint(i)
    return i
